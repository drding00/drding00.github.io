<div id="vector"></div>
    <main>
        <h1 class="section-titles">Latest Episodes</h1>

        <section id="episode-section">

            <div id="featured">
                <h2>November 25th 2019</h2>
                <div class="featured-image"><img src="./images/deadpool.jpg" alt=""/></div>
                <h3>Comicstorian Weekly 11/22</h3>
            </div>


                <div id="episode-list">

                    <div class="episode">
                        <h2>November 22th 2019</h2>
                        <img class="episode-image" src="./images/deadpool.jpg" alt=""></img>
                        <h3>Comicstorian Weekly 11/22</h3>
                    </div>

                    <div class="episode">
                        <h2>November 12th 2019</h2>
                        <img class="episode-image" src="./images/thor.jpg" alt=""></img>
                        <h3>Is There a Plan for Marvel Phase 4?</h3>
                    </div>

                    <div class="episode">
                        <h2>November 20th 2019</h2>
                        <img class="episode-image" src="./images/titans.jpg" alt=""></img>
                        <h3>Tians Season 3 Announced! Why?!</h3>
                    </div>

                    <div class="episode">
                        <h2>October 29th 2019</h2>
                        <img class="episode-image" src="./images/bloodshot.jpg" alt=""></img>
                        <h3>Marvel Movies Suck? Martin Scorsese Comments</h3>
                    </div>

                    <div class="episode">
                        <h2>October 6th 2019</h2>
                        <img class="episode-image" src="./images/thor.jpg" alt=""></img>
                        <h3>Some sort of episode title!</h3>
                    </div>

                    <div class="episode">
                        <h2>October 2nd 2019</h2>
                        <img class="episode-image" src="./images/bloodshot.jpg" alt=""></img>
                        <h3>Yet another episode title! Wooo!</h3>
                    </div>

                </div> <!-- end episodes div -->

        </section>


<div id="watch-button"><a href="#">Watch More</a></div>


    </main>