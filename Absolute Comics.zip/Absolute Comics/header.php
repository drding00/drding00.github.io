<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php bloginfo(); ?></title>

    <link href="https://fonts.googleapis.com/css?family=Anton|Roboto:300,400,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./style.css">


<?php wp_head(); ?>    
</head>

<body <?php body_class($class); ?>>

    <header>
        <div id="header-overlay">

        <nav>
            <?php 
                wp_nav_menu(
                    array(
                        'menu' => 'primary',
                        'container' => 'nav',
                        'depth' => 1
                    )
                );
            ?>
        </nav>

        <div id="logo"><img src="./images/AClogo.png" alt="Absolute Comics logo"/></div>
        <div id="banner-link">Every Tuesday 5pm EST on <a href="">twitch.tv/comicstorian</a></div>

        <ul id="socialmedia-links">
            <li><a href=""><img src="./images/facebook-icon.svg" alt="Absolute Comics Facebook"></a></li>
            <li><a href=""><img src="./images/twitter-icon.svg" alt="Absolute Comics Twitter"></a></li>
            <li><a href=""><img src="./images/youtube-icon.svg" alt="Absolute Comics Youtube"></a></li>
            <li><a href=""><img src="./images/twitch-icon.png" alt="Absolute Comics Twitch"></a></li>
        </ul>
        </div>
    </header>






