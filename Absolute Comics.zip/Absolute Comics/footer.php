<footer>
    <p>All rights reserved Absolute Comics &#169;2019</p>
</footer>


</body>

</html>
<?php wp_footer(); ?>